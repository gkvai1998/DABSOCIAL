# SocialBox-Termux
SocialBox is a Bruteforce Attack Framework [ Facebook , Gmail , Instagram ,Twitter ] , Coded By DirectActionBD Edit By GKVAI
# Installation
```
apt-get update
apt-get install git
git clone https://github.com/gkvai1998/dha.git 
cd dha
chmod +x install-sb.sh
./install-sb.sh
```
# Run
```
./dha.sh
```
# Screenshots :

# Tested On :
* Termux on andriod (tor connected if use vpn )
## Star History


### Donate
- If this project very help you to penetration testing  and u want support me , you can give me a cup of coffee :)

# Contact
* [Telegram](https://t.me/DirectActionBd) - TUPADRE, 4NONYMOU5
* [telegram](https://t.me/AnonymousChittagong) - TUPADRE, 4NONYMOU5
* [telegram](https://t.me/High_Red_Zone_Alert) - TUPADRE, 4NONYMOU5
* [telegram](https://t.me/Message_BD) - TUPADRE, 4NONYMOU5
# Authors :
* TuPadre
* 4nonymou5
* dark
