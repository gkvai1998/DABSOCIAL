# DIRECTACTIONBD v1.0
Multi-thread  BruteForcer in Shell Script

## Author: github.com/gkvai1998
## TG:https://t.me/DirectActionBd

## Legal disclaimer:

Usage of TweetShell for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 

### Features
- Multi-thread (400 pass/min, 20 threads)
- Save/Resume sessions
- Anonymous attack through TOR
- Default password list (best +39k 8 letters)
- Check valid username
- Check and Install all dependencies

### Usage:
```
git clone https://github.com/gkvai/Twiter
cd Twiter
chmod +x Twiter.sh
service tor start
sudo ./Twiter.sh
```

### Install requirements (Curl, Tor):

```
chmod +x install.sh
./install.sh
```
